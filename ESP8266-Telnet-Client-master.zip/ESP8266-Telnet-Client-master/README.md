# ESP8266-Telnet-Client

Based on the excellent work of @alejho. (https://github.com/alejho)

https://github.com/alejho/Arduino-Telnet-Client

